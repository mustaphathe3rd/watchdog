# =============================================================================
# config.py  —  Central Configuration for Naija AI Watchdog
# =============================================================================
# All thresholds, paths, and constants are defined here in one place.
# Every module imports from config.py — no hardcoded magic numbers anywhere.
#
# §3.5.2 System Outputs: "The system is programmed with a high threshold (85%)
# to trigger further action, thereby mitigating the risk of erroneously
# flagging human creators." — this 0.85 value lives here and only here.
# =============================================================================

import os
from pathlib import Path

# ── Project Root ──────────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).resolve().parent

# ── Load .env into the process environment ────────────────────────────────────
# BUG FIX (found in production — a live cookie-auth test showed
# YTDLP_COOKIES_FROM_BROWSER wasn't being picked up despite being set in
# .env). Root cause: nothing in this project ever called load_dotenv().
# python-dotenv was listed in requirements.txt but never actually invoked,
# so every os.getenv() call below only ever saw real shell-level environment
# variables — .env's contents were silently ignored from Day 1 onward.
# This went unnoticed because DATABASE_URL's hardcoded fallback below
# happens to exactly match what most people put in .env, so it *looked*
# like .env was being read when it was actually just coincidentally
# falling back to the same hardcoded default the whole time.
from dotenv import load_dotenv
load_dotenv(BASE_DIR / ".env")


# ── Detection Threshold (§3.5.2 / §3.13) ─────────────────────────────────────
# The Synthetic Probability Score (Psynth) must EXCEED this value to trigger
# the Compliance Mapping and Auto-Complaint modules.
# Rationale: VSD principle (§2.2.3) — protect innocent human creators from
# false accusations. High threshold = low false-positive rate (NFR-01, NFR-03).
PSYNTH_THRESHOLD = 0.85


# ── Fusion Weights (§3.11 Mathematical Framework) ────────────────────────────
FUSION_ALPHA = 0.6


# ── Data Directories (§3.9 Dataset Description) ───────────────────────────────
DATA_DIR          = BASE_DIR / "data"
RAW_VIDEO_DIR     = DATA_DIR / "raw" / "video"
RAW_TEXT_DIR      = DATA_DIR / "raw" / "text"
PROCESSED_DIR     = DATA_DIR / "processed"
PROTECTED_IP_DIR  = DATA_DIR / "protected_ip"
MANIFEST_PATH     = DATA_DIR / "manifest.csv"


# ── Model Checkpoints ─────────────────────────────────────────────────────────
MODELS_DIR        = BASE_DIR / "models"
NLP_MODEL_PATH    = MODELS_DIR / "nlp_watchdog_v1.pt"
CV_MODEL_PATH     = MODELS_DIR / "cv_watchdog_v1.pt"
IP_EMBEDDINGS_PATH = MODELS_DIR / "ip_embeddings.pkl"


# ── Reports Output Directory (§3.13 Document Generation) ─────────────────────
REPORTS_DIR = BASE_DIR / "reports"


# ── NLP Settings (§3.12 B — Textual and Plagiarism Detection Engine) ──────────
NLP_BASE_MODEL = "distilbert-base-uncased"
PERPLEXITY_THRESHOLD = 35.0
BURSTINESS_THRESHOLD = 0.3
IP_SIMILARITY_THRESHOLD = 0.82


# ── CV Settings (§3.12 A — Visual/Video Detection Engine) ────────────────────
FRAME_SAMPLE_RATE_FPS = 1
HUMAN_BLINK_RATE_MIN = 12
HUMAN_BLINK_RATE_MAX = 25
EMOTIONAL_RIGIDITY_THRESHOLD = 3
GAUSSIAN_BLUR_KERNEL = (5, 5)


# ── Database (NFR-04 Auditability / NFR-05 Data Privacy) ─────────────────────
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://watchdog_user:watchdog_pass@localhost:5432/naija_watchdog"
)
STORE_METADATA_ONLY_ON_VIOLATION = True


# ── yt-dlp Authentication (optional — for Facebook/Instagram downloads) ──────
# Both platforms block anonymous automated video downloads. yt-dlp supports
# two ways to authenticate as YOU (never store someone else's credentials):
#
# OPTION 1 (easiest, but fragile in WSL/non-standard installs): pull cookies
# directly from a browser's live storage. Set to 'chrome', 'firefox', 'edge',
# 'brave', etc. Set via .env: YTDLP_COOKIES_FROM_BROWSER=chrome
YTDLP_COOKIES_FROM_BROWSER = os.getenv("YTDLP_COOKIES_FROM_BROWSER", "")

# OPTION 2 (more reliable — recommended if Option 1 fails, e.g. WSL): a
# manually-exported Netscape-format cookies.txt (e.g. via the "Get
# cookies.txt LOCALLY" browser extension). Only used if Option 1 above is
# not set. Set via .env: YTDLP_COOKIES_FILE=cookies.txt
# NEVER commit this file — it contains live session authentication.
YTDLP_COOKIES_FILE = os.getenv("YTDLP_COOKIES_FILE", "")


# ── Flask Dashboard ───────────────────────────────────────────────────────────
FLASK_SECRET_KEY = os.getenv("FLASK_SECRET_KEY", "change-this-in-production")
FLASK_DEBUG      = os.getenv("FLASK_DEBUG", "False").lower() == "true"
FLASK_HOST       = "0.0.0.0"
FLASK_PORT       = 5000


# ── Statutory Mapping (§3.13 Automated Complaint and Enforcement Logic) ───────
STATUTORY_MAP = {
    "DEEPFAKE_IMPERSONATION": {
        "statute": "Nigeria Data Protection Act (NDPA) 2023, Section 37",
        "summary": (
            "Section 37 of the NDPA 2023 grants data subjects the right not to be subject "
            "to decisions based solely on automated processing and profiling."
        ),
        "regulator": "Nigeria Data Protection Commission (NDPC)",
        "action": "Notice and Take-Down; Data Privacy Impact Assessment required.",
    },
    "UNDISCLOSED_SYNTHETIC_AVATAR": {
        "statute": "ARCON Advertising Guidelines (2023) & NDPA 2023, Section 37",
        "summary": (
            "The deployment of an AI-generated avatar to front a commercial advertisement "
            "without explicit disclosure to the consumer constitutes deceptive synthetic "
            "labor substitution."
        ),
        "regulator": "Advertising Regulatory Council of Nigeria (ARCON)",
        "action": "Mandatory AI Disclosure Label; Takedown of non-compliant asset.",
    },
    "IP_SCRAPING_PLAGIARISM": {
        "statute": "Copyright Act 2022, Section 108",
        "summary": (
            "Section 108 of the Copyright Act 2022 protects the works of human authors "
            "from unauthorized reproduction or adaptation."
        ),
        "regulator": "Nigerian Copyright Commission (NCC)",
        "action": "Cease and Desist; Attribution or Licensing required.",
    },
}


# ── Ensure all directories exist on import ────────────────────────────────────
for _dir in [RAW_VIDEO_DIR, RAW_TEXT_DIR, PROCESSED_DIR,
             PROTECTED_IP_DIR, MODELS_DIR, REPORTS_DIR]:
    _dir.mkdir(parents=True, exist_ok=True)
